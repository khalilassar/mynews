package com.example.mynews.database;

import android.graphics.Movie;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.mynews.model.Article;

import java.util.List;

@Dao
public interface ArticleDao {
    @Insert
    public void insert(Article article);
    @Update
    public void update(Article article);
    @Delete
    public void delete(Article article);
    @Query("SELECT * FROM Article")
    LiveData<List<Article>> getBookmarkedArticles();
    @Query("SELECT COUNT(mTitle) FROM Article where mTitle=:title")
    int getBookmarkedCount(String title);
}
