package com.example.mynews.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;

import com.example.mynews.model.Article;

@Database(entities = {Article.class,}, version = 1)
public abstract class MyRoomDatabase extends androidx.room.RoomDatabase {
    //public abstract CategoreyDao categoreyDao();
    //public abstract MealDao mealDao();
    public abstract ArticleDao articleDao();
    private static volatile MyRoomDatabase instance;
    private static Context mContext;


    public static MyRoomDatabase getInstance(Context context) {
        if (instance == null) {
            synchronized (MyRoomDatabase.class){
                instance = Room.databaseBuilder(context.getApplicationContext(),MyRoomDatabase.class,"MyRoomDatabase").build();
                mContext=context;
            }
        }
        return instance;
    }
}
