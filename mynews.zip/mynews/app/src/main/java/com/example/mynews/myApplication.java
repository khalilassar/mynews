package com.example.mynews;

import android.app.Application;
import android.content.res.Resources;
import android.os.Bundle;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.squareup.picasso.Picasso;

public class myApplication extends Application {
    private static Application mInstance;
    private static Resources res;
    private static FirebaseAnalytics firebaseAnalytics;

    @Override
    public void onCreate() {
        super.onCreate();
        Picasso.setSingletonInstance(new Picasso.Builder(getApplicationContext()).build());
        mInstance = this;
        res = getResources();
        firebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, res.getString(R.string.app_name));
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "AndroidVersionInstalled");
        firebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    public static Application getmInstance() {
        return mInstance;
    }

    public static Resources getRes() {
        return res;
    }
}
