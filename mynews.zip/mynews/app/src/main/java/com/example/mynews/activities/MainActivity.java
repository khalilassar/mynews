package com.example.mynews.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.viewpager.widget.ViewPager;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.example.mynews.ArticlesViewModel;
import com.example.mynews.NewAppWidget;
import com.example.mynews.R;
import com.example.mynews.adapters.TabAdapter;
import com.example.mynews.fragments.BookmarksFragment;
import com.example.mynews.fragments.BusinessFragment;
import com.example.mynews.fragments.EntertainmentFragment;
import com.example.mynews.fragments.GeneralFragment;
import com.example.mynews.fragments.HealthFragment;
import com.example.mynews.fragments.ScienceFragment;
import com.example.mynews.fragments.SportsFragment;
import com.example.mynews.fragments.TechnologyFragment;
import com.example.mynews.model.Article;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.tabs.TabLayout;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ArticlesViewModel articlesViewModel;
    private TabAdapter adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private AdView mAdView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        articlesViewModel = ViewModelProviders.of(this).get(ArticlesViewModel.class);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
        adapter = new TabAdapter(getSupportFragmentManager());
        adapter.addFragment(new BookmarksFragment(), getString(R.string.bookmarks_fragment_title));
        adapter.addFragment(new BusinessFragment(), getString(R.string.business_fragment_title));
        adapter.addFragment(new EntertainmentFragment(), getString(R.string.entertainment_fragment_title));
        adapter.addFragment(new GeneralFragment(), getString(R.string.general_fragment_title));
        adapter.addFragment(new HealthFragment(), getString(R.string.health_fragment_title));
        adapter.addFragment(new ScienceFragment(), getString(R.string.science_fragment_title));
        adapter.addFragment(new SportsFragment(), getString(R.string.sports_fragment_title));
        adapter.addFragment(new TechnologyFragment(), getString(R.string.technology_fragment_title));
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.bookmark);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_business);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_entertainment);
        tabLayout.getTabAt(3).setIcon(R.drawable.ic_general);
        tabLayout.getTabAt(4).setIcon(R.drawable.ic_health);
        tabLayout.getTabAt(5).setIcon(R.drawable.ic_science);
        tabLayout.getTabAt(6).setIcon(R.drawable.ic_sports);
        tabLayout.getTabAt(7).setIcon(R.drawable.ic_technology);
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences sharedPref = getSharedPreferences(NewAppWidget.SHARED_PREF_KEY, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        List<Article> articles=articlesViewModel.getBookmarkedArticles().getValue();
        StringBuilder string = new StringBuilder();

        if (articles != null && articles.size()!=0) {
            for (Article article : articles
            ) {
                string.append(getString(R.string.article_string) + "   " + article.getMTitle() + "\n");
            }
        } else {
            string.append(R.string.widget_noarticles_string);
        }
        String widgetString = string.toString();
        editor.putString(NewAppWidget.SHARED_PREF_STRING_KEY,widgetString);
        editor.apply();
        //trigger update maually
        Intent intent = new Intent(this, NewAppWidget.class);
        intent.setAction("android.appwidget.action.APPWIDGET_UPDATE");
        int ids[] = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(), NewAppWidget.class));
        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
        sendBroadcast(intent);
    }
}
