package com.example.mynews.fragments;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.mynews.ArticlesViewModel;
import com.example.mynews.R;
import com.example.mynews.activities.MainActivity;
import com.example.mynews.adapters.ArticleListAdapter;
import com.example.mynews.model.Article;
import com.example.mynews.utils.Utils;

import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class HealthFragment extends Fragment {
    private ArticlesViewModel articlesViewModel;
    private RecyclerView rv;
    private SwipeRefreshLayout swipeLayout;
    private ArticleListAdapter adapter;

    public HealthFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_health, container, false);
        articlesViewModel = ViewModelProviders.of(getActivity()).get(ArticlesViewModel.class);
        rv = v.findViewById(R.id.list_articles_rv);
        swipeLayout = v.findViewById(R.id.swipe_container);
        adapter = new ArticleListAdapter();
        rv.setAdapter(adapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        rv.setLayoutManager(linearLayoutManager);
        rv.setHasFixedSize(true);
        articlesViewModel.getHealthArticles().observe(this, new Observer<List<Article>>() {
            @Override
            public void onChanged(List<Article> articles) {
                adapter.setmArticles(articles);
                adapter.notifyDataSetChanged();
                swipeLayout.setRefreshing(false);
            }
        });
        swipeLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                articlesViewModel.updateArticlesList(Utils.CATEGOREY_HEALTH);
            }
        });
        return v;
    }

}
