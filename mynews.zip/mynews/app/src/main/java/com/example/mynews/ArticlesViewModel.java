package com.example.mynews;

import android.app.Application;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.mynews.database.MyRoomDatabase;
import com.example.mynews.model.Article;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.example.mynews.utils.Utils;

public class ArticlesViewModel extends AndroidViewModel {
    private Application application;
    private MutableLiveData<List<Article>> businessArticles;
    private MutableLiveData<List<Article>> entertainmentArticles;
    private MutableLiveData<List<Article>> generalArticles;
    private MutableLiveData<List<Article>> healthArticles;
    private MutableLiveData<List<Article>> scienceArticles;
    private MutableLiveData<List<Article>> sportsArticles;
    private MutableLiveData<List<Article>> technologyArticles;
    private LiveData<List<Article>> bookmarksArticles;


    public ArticlesViewModel(@NonNull Application application) {
        super(application);
        this.application = application;
        //get database instanse
    }

    public LiveData<List<Article>> getBusinessArticles() {
        if (businessArticles != null) {
            return businessArticles;
        } else {
            businessArticles = new MutableLiveData<>();
            updateArticlesList(Utils.CATEGOREY_BUSINESS);
            return businessArticles;
        }

    }

    public LiveData<List<Article>> getEntertainmentArticles() {
        if (entertainmentArticles != null) {
            return entertainmentArticles;
        } else {
            entertainmentArticles = new MutableLiveData<>();
            updateArticlesList(Utils.CATEGOREY_EMTERTAINMENT);
            return entertainmentArticles;
        }
    }

    public LiveData<List<Article>> getGeneralArticles() {
        if (generalArticles != null) {
            return generalArticles;
        } else {
            generalArticles = new MutableLiveData<>();
            updateArticlesList(Utils.CATEGOREY_GENERAL);
            return generalArticles;
        }

    }

    public LiveData<List<Article>> getHealthArticles() {
        if (healthArticles != null) {
            return healthArticles;
        } else {
            healthArticles = new MutableLiveData<>();
            updateArticlesList(Utils.CATEGOREY_HEALTH);
            return healthArticles;
        }
    }

    public LiveData<List<Article>> getScienceArticles() {
        if (scienceArticles != null) {
            return scienceArticles;
        } else {
            scienceArticles = new MutableLiveData<>();
            updateArticlesList(Utils.CATEGOREY_SCIENCE);
            return scienceArticles;
        }

    }

    public LiveData<List<Article>> getSportsArticles() {
        if (sportsArticles != null) {
            return sportsArticles;
        } else {
            sportsArticles = new MutableLiveData<>();
            updateArticlesList(Utils.CATEGOREY_SPORTS);
            return sportsArticles;
        }

    }

    public LiveData<List<Article>> getTechnologyArticles() {
        if (technologyArticles != null) {
            return technologyArticles;
        } else {
            technologyArticles = new MutableLiveData<>();
            updateArticlesList(Utils.CATEGOREY_TECHNOLOGY);
            return technologyArticles;
        }
    }
    public LiveData<List<Article>> getBookmarkedArticles() {
        if (bookmarksArticles != null) {
            return bookmarksArticles;
        } else {
            bookmarksArticles = MyRoomDatabase.getInstance(application).articleDao().getBookmarkedArticles();
            return bookmarksArticles;
        }
    }

    public void updateArticlesList(final String CATEGOREY) {
        RequestQueue queue = Volley.newRequestQueue(application);
        URL url = Utils.getCategoreyURL(CATEGOREY);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url.toString(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response == null) {
                            Toast.makeText(application, " error updating data", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        List<Article> articles = Utils.getArticlesFromResponse(response);
                        switch (CATEGOREY) {
                            case Utils.CATEGOREY_BUSINESS: {
                                businessArticles.setValue(articles);
                                Toast.makeText(application, CATEGOREY + " articles updated", Toast.LENGTH_SHORT).show();
                                break;
                            }
                            case Utils.CATEGOREY_EMTERTAINMENT: {
                                entertainmentArticles.setValue(articles);
                                Toast.makeText(application, CATEGOREY + " articles updated", Toast.LENGTH_SHORT).show();

                                break;
                            }
                            case Utils.CATEGOREY_GENERAL: {
                                generalArticles.setValue(articles);
                                Toast.makeText(application, CATEGOREY + " articles updated", Toast.LENGTH_SHORT).show();

                                break;
                            }
                            case Utils.CATEGOREY_HEALTH: {
                                healthArticles.setValue(articles);
                                Toast.makeText(application, CATEGOREY + " articles updated", Toast.LENGTH_SHORT).show();

                                break;
                            }
                            case Utils.CATEGOREY_SCIENCE: {
                                scienceArticles.setValue(articles);
                                Toast.makeText(application, CATEGOREY + " articles updated", Toast.LENGTH_SHORT).show();

                                break;
                            }
                            case Utils.CATEGOREY_SPORTS: {
                                sportsArticles.setValue(articles);
                                Toast.makeText(application, CATEGOREY + " articles updated", Toast.LENGTH_SHORT).show();

                                break;
                            }
                            case Utils.CATEGOREY_TECHNOLOGY: {
                                technologyArticles.setValue(articles);
                                Toast.makeText(application, CATEGOREY + " articles updated", Toast.LENGTH_SHORT).show();

                                break;
                            }
                            default: {
                                Toast.makeText(application, " error updating data", Toast.LENGTH_SHORT).show();
                                break;
                            }
                        }

                        //  trailerSwipeLayout.setRefreshing(false);
                        //  trailerSwipeLayout.setEnabled(false);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(application, "check internet", Toast.LENGTH_SHORT).show();
                // trailerSwipeLayout.setRefreshing(false);
                // trailerSwipeLayout.setEnabled(false);
            }
        });
        queue.add(stringRequest);
    }
}
