package com.example.mynews.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.mynews.database.MyRoomDatabase;
import com.example.mynews.R;
import com.example.mynews.model.Article;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    private ImageView ArticleImg;
    private FloatingActionButton fab;
    private Article article;
    private WebView webView;
    private boolean bookmarked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            article = getIntent().getParcelableExtra("article");
        } catch (Exception e) {
            e.printStackTrace();
        }
        setContentView(R.layout.activity_details);
        fab = findViewById(R.id.details_nestedscrool_fab);
        webView = findViewById(R.id.webView);
        initilzeWebView();
        Toolbar toolBar = findViewById(R.id.details_toolbar);
        setSupportActionBar(toolBar);
        ArticleImg = findViewById(R.id.details_img);

        Picasso.get().load(article.getMUrlToImage()).into(ArticleImg);
        final CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.details_collapstoolbar);
        AppBarLayout appBarLayout = findViewById(R.id.details_appbar);
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = true;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                if (scrollRange + verticalOffset == 0) {
                    collapsingToolbarLayout.setTitle(article.getMTitle());
                    isShow = true;
                } else if (isShow) {
                    collapsingToolbarLayout.setTitle(article.getMDescription());
                    collapsingToolbarLayout.setExpandedTitleColor(Color.WHITE);
                    isShow = false;
                }
            }
        });
        final MyRoomDatabase db = MyRoomDatabase.getInstance(this);
        new AsyncTask<String, Void, Integer>() {
            @Override
            protected void onPostExecute(Integer integer) {
                if (integer == 0) {
                    fab.setColorFilter(Color.TRANSPARENT);
                    bookmarked = false;
                } else if (integer == 1) {
                    fab.setColorFilter(Color.YELLOW);
                    bookmarked = true;
                } else {
                    finish();
                }
            }

            @Override
            protected Integer doInBackground(String... strings) {
                return db.articleDao().getBookmarkedCount(strings[0]);
            }
        }.execute(article.getMTitle());
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bookmarked) {
                    new AsyncTask<Article, Void, Void>() {

                        @Override
                        protected void onPostExecute(Void aVoid) {
                            fab.setColorFilter(Color.TRANSPARENT);
                            bookmarked=false;
                        }

                        @Override
                        protected Void doInBackground(Article... articles) {
                            db.articleDao().delete(articles[0]);
                            return null;
                        }
                    }
                            .execute(article);
                } else {
                    new AsyncTask<Article, Void, Void>() {

                        @Override
                        protected void onPostExecute(Void aVoid) {
                            fab.setColorFilter(Color.YELLOW);
                            bookmarked=true;
                        }

                        @Override
                        protected Void doInBackground(Article... articles) {
                            db.articleDao().insert(articles[0]);
                            return null;
                        }
                    }
                            .execute(article);
                }
            }
        });
    }

    private void initilzeWebView() {
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.loadUrl(article.getMUrl());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.details_menu, menu);
        return true;
    }

}
