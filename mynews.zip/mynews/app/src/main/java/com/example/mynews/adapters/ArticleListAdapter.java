package com.example.mynews.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mynews.activities.DetailsActivity;
import com.example.mynews.R;
import com.example.mynews.model.Article;
import com.squareup.picasso.Picasso;


public class ArticleListAdapter extends RecyclerView.Adapter<ArticleListAdapter.ArticleHolder> {
    List<Article> mArticles;
    Context context;


    @NonNull
    @Override
    public ArticleHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.article_row, parent, false);
        ArticleHolder recipeHolder = new ArticleHolder(v);
        context = parent.getContext();
        return recipeHolder;
    }

    public void onBindViewHolder(@NonNull final ArticleHolder holder, final int position) {
        Article article = mArticles.get(position);
        Picasso.get().load(article.getMUrlToImage()).fit().centerCrop().into(holder.articleImg);
        holder.articleTitle.setText(article.getMTitle());
        holder.articleDescription.setText(article.getMDescription());
        String author = article.getMAuthor();
        if (author.equals("null") || author.isEmpty()) {
            holder.articleSource.setText(article.getMSourceName());
        } else {
            holder.articleSource.setText(article.getMSourceName()+"."+article.getMAuthor());
        }

        holder.articleImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra("article", mArticles.get(holder.getAdapterPosition()));
                context.startActivity(intent);
            }
        });


    }

    public int getItemCount() {
        if (mArticles == null) {
            return 0;
        } else {
            return mArticles.size();
        }
    }


    protected class ArticleHolder extends RecyclerView.ViewHolder {
        ImageView articleImg;
        TextView articleTitle;
        TextView articleDescription;
        TextView articleSource;


        public ArticleHolder(@NonNull View itemView) {
            super(itemView);
            articleImg = itemView.findViewById(R.id.newsIv);
            articleTitle = itemView.findViewById(R.id.newsHeadingTv);
            articleDescription = itemView.findViewById(R.id.newsDescTv);
            articleSource = itemView.findViewById(R.id.newsSourceTv);

        }
    }

    public List<Article> getmArticles() {
        return mArticles;
    }

    public void setmArticles(List<Article> mArticles) {
        this.mArticles = mArticles;
    }

    public interface OnArticleClickedListener {
    }


}
