package com.example.mynews.utils;

import android.net.Uri;

import com.example.mynews.model.Article;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Utils {
    public static final String Key_PARAM = "apiKey";
    public static final String NEWS_API_KEY = "d7c409e7206148bea318512891d695e8";
    public static final String CATEGOREY_PARAM = "category";
    public static final String CATEGOREY_BUSINESS = "business";
    public static final String CATEGOREY_EMTERTAINMENT = "entertainment";
    public static final String CATEGOREY_GENERAL = "general";
    public static final String CATEGOREY_HEALTH = "health";
    public static final String CATEGOREY_SCIENCE = "science";
    public static final String CATEGOREY_SPORTS = "sports";
    public static final String CATEGOREY_TECHNOLOGY = "technology";
    public static final String COUNTREY_PARAM = "country";
    public static final String COUNTREY_US = "us";
    public static final String BASE_URL = " https://newsapi.org/v2/top-headlines";

    public static URL getCategoreyURL(String CATEGOREY) {
        Uri uri = Uri.parse(BASE_URL).buildUpon()
                .appendQueryParameter(COUNTREY_PARAM, COUNTREY_US)
                .appendQueryParameter(CATEGOREY_PARAM, CATEGOREY)
                .appendQueryParameter(Key_PARAM, NEWS_API_KEY)
                .build();
        URL url = null;
        try {
            url = new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return url;
    }

    public static ArrayList<Article> getArticlesFromResponse(String response) {
        JSONObject jSONObject = null;
        try {
            jSONObject = new JSONObject(response);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        String status = jSONObject.optString("status", " ");
        if (!status.equals("ok")) {
            return null;
        }

        JSONArray articlesJSONArray = null;
        try {
            articlesJSONArray = jSONObject.getJSONArray("articles");
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }

        ArrayList<Article> articles = new ArrayList<Article>();


        for (int i = 0; i < articlesJSONArray.length(); i++) {
            try {
                Article article = new Article();
                JSONObject jSONArticle = (JSONObject) articlesJSONArray.get(i);
                article.setmAuthor(jSONArticle.optString("author", " "));
                article.setmTitle(jSONArticle.optString("title", " "));
                article.setmDescription(jSONArticle.optString("description", " "));
                article.setmUrl(jSONArticle.optString("url", " "));
                article.setmUrlToImage(jSONArticle.optString("urlToImage", " "));
                article.setmPublishedAt(jSONArticle.optString("publishedAt", " "));
                article.setmContent(jSONArticle.optString("content", " "));
                JSONObject sourcejSONObject = (JSONObject) jSONArticle.get("source");
                article.setmSourceId(sourcejSONObject.optString("id", " "));
                article.setmSourceName(sourcejSONObject.optString("name", " "));
                articles.add(article);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        return articles;
    }


}
